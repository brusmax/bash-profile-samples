# !/bin/bash
# Script to declare and use variables


echo "User $name has selected option $option"
