# !/bin/bash
# Script package files with command tar 
# Author: @brusmax - hola@brusmax.com

echo "Package sh files to tar"
tar -cvf shellSamples.tar *.sh

