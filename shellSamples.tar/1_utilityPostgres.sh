# !/bin/bash
# Script to do some postgres's utility operations
echo "Welcome to this Postgres utility program"
