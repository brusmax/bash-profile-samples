# !/bin/bash
# Script arguments examples
# Author: @brusmax - hola@brusmax.com

curseName=$1
schedule=$2

echo "Curse name is: $curseName which is at: $schedule"
echo "Number of params sent: $#"
echo "Params sent: $*"

